# Templatemail Form Agendamento ETA

## Para fazer

- [x] Criar formulário para criação do template.
- [x] Aplicar estilos para melhorar o visual da aplicação.
- [ ] Criar gerador de modelo com javascript.
- [ ] Remover comportamento padrão de envio de formulário (submit) para não fazer estas requisições.
- [ ] Tornar exportável para arquivo de texto.
- [ ] Gerar favicons com compatibilidade de navegadores e plataformas usando o [Real Favicon Generator](https://realfavicongenerator.net/).
- [ ] Tornar "instalável" configurando a página como um PWA.
- [ ] Criar ícone "maskable" para PWA utilizando o [Maskable.app](https://maskable.app/).