const ModAgForm = document.querySelector("form[name=TI_scheduling]");

ModAgForm.querySelectorAll('button')